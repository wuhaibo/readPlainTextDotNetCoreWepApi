﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace requestPlainText.Controllers
{
    [Route("api/[controller]/[action]")]
    public class ValuesController : Controller
    {

        [HttpPost]
        [ActionName("GetJsonString2")]
        public string GetJsonString2([FromBody]string content)
        {

            var reader = new StreamReader(Request.Body);
            var contentFromBody = reader.ReadToEnd();
            
            Request.Body.Position = 0;
            
            var reader2 = new StreamReader(Request.Body);
            
            var contentFromBody2 = reader2.ReadToEnd();


            return "content: " + content 
                   + " contentFromBody: " + contentFromBody
                   + " contentFromBody2: " + contentFromBody2;
        }

         
        [HttpPost]
        [ActionName("GetJsonString")]

        public string GetJsonString([FromBody]string content)
        {
            return "content: " + content ;         
        }

        [HttpPost]
        [ActionName("GetJsonString3")]
        public string GetJsonString3(string content)
        {
            var reader = new StreamReader(Request.Body);
            var contentFromBody = reader.ReadToEnd();
            return "content: " + content 
                   + " contentFromBody: " + contentFromBody;
        }
    }
}
